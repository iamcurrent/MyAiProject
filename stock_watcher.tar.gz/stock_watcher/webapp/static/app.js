"use strict";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const screenerCondDesc = [
  "涨幅 3%~5%", "量比 > 1", "换手率 5%~10%", "流通市值 50~200亿",
  "近期放量趋势", "均线多头向上发散", "分时强于大盘",
];

const state = {
  watchlist: [],
  quotes: {},
  selected: null,
  chartMode: "kline",
  charts: {},
  refreshMs: 5000,
  notifying: false,
  alertLog: [],
};

const fmt = {
  wan(v) {
    if (v === null || v === undefined || isNaN(v)) return "--";
    const a = Math.abs(v);
    if (a >= 10000) return (v / 10000).toFixed(2) + "亿";
    return Math.round(v) + "万";
  },
  money(v) {
    if (v === null || v === undefined || isNaN(v)) return "--";
    const a = Math.abs(v);
    if (a >= 100000000) return (v / 100000000).toFixed(2) + "亿";
    if (a >= 10000) return (v / 10000).toFixed(2) + "万";
    return Math.round(v);
  },
};

const api = {
  async get(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error(r.status + " " + url);
    return r.json();
  },
  async post(url, body) {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return r.json();
  },
  async del(url) {
    const r = await fetch(url, { method: "DELETE" });
    return r.json();
  },
};

/* ================= 自选盯盘 ================= */

async function loadWatchlist() {
  const res = await api.get("/api/watchlist");
  state.watchlist = res.watchlist || [];
  if (!state.selected && state.watchlist.length) state.selected = state.watchlist[0];
  renderWatchlist();
  refreshQuotes();
}

function renderWatchlist() {
  const tbody = $("#watch-table tbody");
  tbody.innerHTML = "";
  if (!state.watchlist.length) {
    const tr = document.createElement("tr");
    tr.innerHTML = '<td colspan="12" style="color:#8b98a9;padding:30px">暂无自选股，请在顶部输入代码添加</td>';
    tbody.appendChild(tr);
    return;
  }
  state.watchlist.forEach((sym) => {
    const q = state.quotes[sym] || {};
    const tr = document.createElement("tr");
    tr.dataset.symbol = sym;
    if (sym === state.selected) tr.classList.add("selected");
    const pct = q.change_pct;
    const cls = pct > 0 ? "up" : pct < 0 ? "down" : "flat";
    const arrow = pct > 0 ? "▲" : pct < 0 ? "▼" : "—";
    tr.innerHTML = `
      <td class="${cls}">${(q.code || sym).toUpperCase()}</td>
      <td>${q.name || "--"}</td>
      <td class="${cls}">${q.price != null ? q.price.toFixed(2) : "--"}</td>
      <td class="${cls}">${pct != null ? arrow + " " + pct.toFixed(2) + "%" : "--"}</td>
      <td class="${cls}">${q.change != null ? q.change.toFixed(2) : "--"}</td>
      <td>${q.open != null ? q.open.toFixed(2) : "--"}</td>
      <td class="${cls}">${q.high != null ? q.high.toFixed(2) : "--"}</td>
      <td>${q.low != null ? q.low.toFixed(2) : "--"}</td>
      <td class="col-blue">${q.turnover_rate != null ? q.turnover_rate.toFixed(2) + "%" : "--"}</td>
      <td class="col-yellow">${q.volume_ratio != null ? q.volume_ratio.toFixed(2) : "--"}</td>
      <td>${q.amount != null ? fmt.money(q.amount * 10000) : "--"}</td>
      <td><button class="del-btn" data-del="${sym}">删除</button></td>`;
    tr.addEventListener("click", () => selectStock(sym));
    tbody.appendChild(tr);
  });
  $$("#watch-table tbody tr").forEach((tr) => {
    const del = tr.querySelector(".del-btn");
    if (del) del.addEventListener("click", (e) => {
      e.stopPropagation();
      removeStock(del.dataset.del);
    });
  });
}

async function refreshQuotes() {
  if (!state.watchlist.length) {
    $("#watch-status").textContent = "";
    renderWatchlist();
    return;
  }
  try {
    const list = await api.get("/api/quotes?codes=" + state.watchlist.join(","));
    state.quotes = {};
    list.forEach((q) => { state.quotes[q.symbol] = q; });
    renderWatchlist();
    updateDetail();
    $("#watch-status").textContent = "更新于 " + new Date().toLocaleTimeString();
    setConn(true);
  } catch (e) {
    setConn(false);
    $("#watch-status").textContent = "行情获取失败: " + e.message;
  }
}

function setConn(ok) {
  const dot = $("#conn-status");
  dot.className = "status-dot " + (ok ? "ok" : "err");
}

/* ================= 详情 ================= */

async function selectStock(sym) {
  state.selected = sym;
  renderWatchlist();
  resetDetail();
  loadDetail(sym);
}

function resetDetail() {
  $("#d-name").textContent = "--";
  $("#d-code").textContent = "--";
  $("#d-price").textContent = "--";
  $("#d-change").textContent = "--";
  $("#d-price").className = "d-price";
  $("#d-change").className = "d-change";
  ["ma5","ma10","ma20","ma60","macd","dif","dea","rsi6","rsi12","rsi24","k","d","j","vr","tech","state"]
    .forEach((k) => { const el = $("#i-" + k); el.textContent = "--"; el.className = ""; });
  ["main","ratio","super","large","medium","small"].forEach((k) => {
    $("#f-" + k).textContent = "--";
    $("#f-" + k).className = "";
  });
}

async function loadDetail(sym) {
  const q = state.quotes[sym];
  if (q) applyQuoteToDetail(q);
  await Promise.all([
    loadKline(sym),
    loadMinute(sym),
    loadIndicators(sym),
    loadFundflow(sym),
  ]);
}

function applyQuoteToDetail(q) {
  if (!q) return;
  const pct = q.change_pct;
  const cls = pct > 0 ? "up" : pct < 0 ? "down" : "flat";
  $("#d-name").textContent = q.name || "--";
  $("#d-code").textContent = q.symbol || "--";
  $("#d-price").textContent = q.price != null ? q.price.toFixed(2) : "--";
  $("#d-change").textContent = (pct != null ? (pct > 0 ? "+" : "") + pct.toFixed(2) + "%" : "--")
    + "  " + (q.change != null ? (q.change > 0 ? "+" : "") + q.change.toFixed(2) : "");
  $("#d-price").className = "d-price " + cls;
  $("#d-change").className = "d-change " + cls;
}

async function loadKline(sym) {
  try {
    const d = await api.get("/api/kline?code=" + sym + "&count=120");
    renderKline(d);
  } catch (e) {
    console.error("K线加载失败", sym, e);
  }
}

async function loadMinute(sym) {
  try {
    const d = await api.get("/api/minute?code=" + sym);
    renderMinute(d);
  } catch (e) {
    console.error("分时加载失败", sym, e);
  }
}

async function loadIndicators(sym) {
  try {
    const d = await api.get("/api/indicators?code=" + sym);
    applyIndicators(d);
  } catch (e) {
    console.error("指标加载失败", sym, e);
  }
}

async function loadFundflow(sym) {
  try {
    const d = await api.get("/api/fundflow?code=" + sym);
    applyFundflow(d);
  } catch (e) {
    const ff = $("#fundflow");
    ff.innerHTML = '<div class="hint" style="padding:6px 0">暂无资金流数据</div>';
  }
}

function updateDetail() {
  const q = state.quotes[state.selected];
  if (q) applyQuoteToDetail(q);
}

function applyIndicators(d) {
  const v = (el, val, digits) => {
    if (!el) return;
    if (val === null || val === undefined || isNaN(val)) {
      el.textContent = "--";
      el.className = "";
      return;
    }
    el.textContent = digits != null ? val.toFixed(digits) : val;
    el.className = val > 0 ? "up" : val < 0 ? "down" : "";
  };
  v($("#i-ma5"), d.ma5, 2); v($("#i-ma10"), d.ma10, 2);
  v($("#i-ma20"), d.ma20, 2); v($("#i-ma60"), d.ma60, 2);
  v($("#i-macd"), d.macd, 3); v($("#i-dif"), d.dif, 3); v($("#i-dea"), d.dea, 3);
  v($("#i-rsi6"), d.rsi6, 1); v($("#i-rsi12"), d.rsi12, 1); v($("#i-rsi24"), d.rsi24, 1);
  v($("#i-k"), d.kdj_k, 1); v($("#i-d"), d.kdj_d, 1); v($("#i-j"), d.kdj_j, 1);
  const vr = $("#i-vr");
  if (vr) {
    vr.textContent = d.volume_ratio != null ? d.volume_ratio.toFixed(2) : "--";
    vr.className = d.volume_anomaly ? "up" : "";
  }
  const tech = $("#i-tech");
  if (tech && d.tech_score != null) {
    tech.textContent = d.tech_score.toFixed(1);
    tech.className = d.tech_score >= 60 ? "up" : d.tech_score >= 40 ? "col-yellow" : "down";
  }
  const st = $("#i-state");
  if (st) {
    st.textContent = d.tech_bullish ? "多头形态" : "空头/弱势";
    st.className = d.tech_bullish ? "up" : "down";
  }
}

function applyFundflow(d) {
  if (!d || d.error) return;
  $("#ff-ts").textContent = "数据时间 " + (d.ts || "");
  const set = (k, v) => {
    const el = $("#f-" + k);
    el.textContent = fmt.wan(v);
    el.className = (v === null || v === undefined || isNaN(v)) ? "" : ((v || 0) >= 0 ? "up" : "down");
  };
  set("main", d.main_netflow);
  const ratio = $("#f-ratio");
  ratio.textContent = d.main_net_ratio != null ? (d.main_net_ratio > 0 ? "+" : "") + d.main_net_ratio.toFixed(2) + "%" : "--";
  ratio.className = (d.main_net_ratio || 0) >= 0 ? "up" : "down";
  set("super", d.super_large); set("large", d.large);
  set("medium", d.medium); set("small", d.small);
}

/* ================= 主力资金 20日历史悬浮 ================= */

let ffhChart = null;
let ffhLoading = false;
let ffhCache = {};

async function loadFundflowHistory(sym) {
  if (ffhLoading) return;
  if (ffhCache[sym] && ffhCache[sym].ts && Date.now() - ffhCache[sym].ts < 60000) {
    renderFundflowHistory(ffhCache[sym].data);
    return;
  }
  ffhLoading = true;
  $("#ffh-status").textContent = "加载中...";
  try {
    const d = await api.get("/api/fundflow/history?code=" + sym + "&days=20");
    ffhCache[sym] = { ts: Date.now(), data: d };
    renderFundflowHistory(d);
  } catch (e) {
    $("#ffh-status").textContent = "加载失败";
  } finally {
    ffhLoading = false;
  }
}

function renderFundflowHistory(d) {
  const rows = (d && d.rows) || [];
  const status = $("#ffh-status");
  if (!rows.length) {
    status.textContent = "暂无历史数据";
    return;
  }
  status.textContent = "共 " + rows.length + " 日";
  const dates = rows.map((r) => r.date.slice(5));
  const mains = rows.map((r) => +(r.main_net / 10000).toFixed(0));

  const el = document.getElementById("ffh-chart");
  if (!ffhChart) ffhChart = echarts.init(el);
  ffhChart.setOption({
    backgroundColor: "transparent",
    animation: false,
    grid: { left: 50, right: 12, top: 16, bottom: 22 },
    tooltip: {
      trigger: "axis",
      formatter: (ps) => {
        const p = ps[0];
        const r = rows[p.dataIndex];
        return r.date + "<br/>主力净流入: " + fmt.wan(r.main_net / 10000)
          + "<br/>超大单: " + fmt.wan(r.super_large / 10000)
          + "<br/>大单: " + fmt.wan(r.large / 10000)
          + "<br/>中单: " + fmt.wan(r.medium / 10000)
          + "<br/>小单: " + fmt.wan(r.small / 10000);
      },
    },
    xAxis: {
      type: "category", data: dates,
      axisLine: { lineStyle: { color: "#26313f" } },
      axisLabel: { color: "#8b98a9", fontSize: 9, interval: 1 },
    },
    yAxis: {
      type: "value",
      splitLine: { lineStyle: { color: "#1c2530" } },
      axisLabel: { color: "#8b98a9", fontSize: 9, formatter: (v) => (Math.abs(v) >= 10000 ? (v / 10000).toFixed(1) + "亿" : v) },
    },
    series: [{
      name: "主力净流入", type: "bar", data: mains,
      barWidth: "55%",
      itemStyle: { color: (p) => (p.value >= 0 ? "#f0524d" : "#3aa675") },
    }],
  }, true);

  const listEl = $("#ffh-list");
  const sum = rows.reduce((a, r) => a + r.main_net, 0);
  let html = "<table><tr><th>日期</th><th>主力净流入</th><th>超大单</th><th>大单</th></tr>";
  rows.slice().reverse().forEach((r) => {
    const cls = r.main_net >= 0 ? "up" : "down";
    html += "<tr><td>" + r.date.slice(5) + "</td>"
      + '<td class="' + cls + '">' + fmt.wan(r.main_net / 10000) + "</td>"
      + "<td>" + fmt.wan(r.super_large / 10000) + "</td>"
      + "<td>" + fmt.wan(r.large / 10000) + "</td></tr>";
  });
  html += "</table>";
  html += '<div class="hint" style="margin-top:4px">20日主力累计: ' + fmt.wan(sum / 10000) + "</div>";
  listEl.innerHTML = html;
}

function showFundflowPopup() {
  if (!state.selected) return;
  const popup = $("#ff-popup");
  popup.classList.add("show");
  loadFundflowHistory(state.selected);
}

function hideFundflowPopup() {
  $("#ff-popup").classList.remove("show");
}

/* ================= ECharts ================= */

function getChart(id) {
  if (!state.charts[id]) {
    const el = document.getElementById(id);
    if (!el) return null;
    state.charts[id] = echarts.init(el);
  }
  return state.charts[id];
}

function renderKline(d) {
  if (state.chartMode !== "kline" || !d.klines || !d.klines.length) return;
  const chart = getChart("chart");
  const klines = d.klines;
  const dates = klines.map((k) => k[0]);
  const candles = klines.map((k) => [k[1], k[2], k[3], k[4]]);
  const volumes = klines.map((k) => k[5]);

  const series = [{
    name: "K线", type: "candlestick", data: candles,
    itemStyle: { color: "#f0524d", color0: "#3aa675", borderColor: "#f0524d", borderColor0: "#3aa675" },
  }];
  const maColors = { "5": "#f5c542", "10": "#58a6ff", "20": "#e07ad8", "60": "#8b98a9" };
  Object.keys(d.ma || {}).forEach((p) => {
    const vals = d.ma[p].map((v, i) => (v === null ? "-" : +v.toFixed(2)));
    series.push({
      name: "MA" + p, type: "line", data: vals, smooth: true, showSymbol: false,
      lineStyle: { width: 1, color: maColors[p] },
    });
  });

  const macdSeries = [];
  if (d.macd) {
    const macdBars = d.macd.macd.map((v) => (
      v === null ? "-" : {
        value: +v.toFixed(3),
        itemStyle: { color: v >= 0 ? "#f0524d" : "#3aa675" },
      }
    ));
    macdSeries.push(
      { name: "MACD", type: "bar", xAxisIndex: 2, yAxisIndex: 2, data: macdBars },
      { name: "DIF", type: "line", xAxisIndex: 2, yAxisIndex: 2, data: d.macd.dif.map((v) => (v === null ? "-" : +v.toFixed(3))), showSymbol: false, lineStyle: { width: 1, color: "#f5c542" } },
      { name: "DEA", type: "line", xAxisIndex: 2, yAxisIndex: 2, data: d.macd.dea.map((v) => (v === null ? "-" : +v.toFixed(3))), showSymbol: false, lineStyle: { width: 1, color: "#58a6ff" } },
    );
  }

  chart.setOption({
    backgroundColor: "transparent",
    animation: false,
    tooltip: { trigger: "axis", axisPointer: { type: "cross" } },
    legend: { textStyle: { color: "#8b98a9" }, top: 0 },
    axisPointer: { link: [{ xAxisIndex: "all" }] },
    grid: [
      { left: 62, right: 24, top: 32, height: "46%" },
      { left: 62, right: 24, top: "55%", height: "17%" },
      { left: 62, right: 24, top: "76%", height: "17%" },
    ],
    xAxis: [
      { type: "category", data: dates, boundaryGap: true, axisLine: { lineStyle: { color: "#26313f" } }, axisLabel: { color: "#8b98a9" } },
      { type: "category", gridIndex: 1, data: dates, axisLine: { lineStyle: { color: "#26313f" } }, axisLabel: { show: false } },
      { type: "category", gridIndex: 2, data: dates, axisLine: { lineStyle: { color: "#26313f" } }, axisLabel: { color: "#8b98a9", fontSize: 10, interval: 3 } },
    ],
    yAxis: [
      { scale: true, splitNumber: 4, splitLine: { lineStyle: { color: "#1c2530" } }, axisLabel: { color: "#8b98a9", fontSize: 10 } },
      { gridIndex: 1, splitNumber: 2, splitLine: { show: false }, axisLabel: { color: "#8b98a9", fontSize: 10, formatter: (v) => (v >= 10000 ? (v / 10000).toFixed(1) + "万" : v) } },
      { gridIndex: 2, splitNumber: 2, splitLine: { lineStyle: { color: "#1c2530" } }, axisLabel: { color: "#8b98a9", fontSize: 10, formatter: (v) => v.toFixed(2) } },
    ],
    dataZoom: [
      { type: "inside", xAxisIndex: [0, 1, 2], start: 55, end: 100 },
      { type: "slider", xAxisIndex: [0, 1, 2], bottom: 2, height: 16, start: 55, end: 100 },
    ],
    series: series.concat([
      { name: "成交量", type: "bar", xAxisIndex: 1, yAxisIndex: 1, data: volumes, itemStyle: { color: "#3a4a5f" } },
    ], macdSeries),
  }, true);
}

function renderMinute(d) {
  if (state.chartMode !== "minute") return;
  const chart = getChart("chart");
  const times = (d.times || []).map((t) => t.slice(0, 2) + ":" + t.slice(2));
  const prices = (d.prices || []).map((p) => (p === null ? "-" : +p.toFixed(2)));
  const avg = (d.avg_prices || []).map((p) => (p ? +p.toFixed(2) : "-"));
  const vols = (d.volumes || []).map((v) => (v === null ? "-" : v));
  const prev = d.prev_close || 0;

  chart.setOption({
    backgroundColor: "transparent",
    animation: false,
    tooltip: { trigger: "axis", axisPointer: { type: "cross" } },
    legend: { textStyle: { color: "#8b98a9" }, top: 0 },
    grid: [
      { left: 55, right: 20, top: 26, height: "58%" },
      { left: 55, right: 20, top: "72%", height: "18%" },
    ],
    xAxis: [
      { type: "category", data: times, boundaryGap: false, axisLine: { lineStyle: { color: "#26313f" } }, axisLabel: { color: "#8b98a9" } },
      { type: "category", gridIndex: 1, data: times, axisLine: { lineStyle: { color: "#26313f" } }, axisLabel: { show: false } },
    ],
    yAxis: [
      { scale: true, splitLine: { lineStyle: { color: "#1c2530" } }, axisLabel: { color: "#8b98a9" } },
      { gridIndex: 1, splitLine: { show: false }, axisLabel: { color: "#8b98a9" } },
    ],
    series: [
      { name: "价格", type: "line", data: prices, showSymbol: false, lineStyle: { width: 1.2, color: "#58a6ff" } },
      { name: "均价", type: "line", data: avg, showSymbol: false, lineStyle: { width: 1, color: "#f5c542" } },
      { name: "昨收", type: "line", data: times.map(() => prev.toFixed(2)), showSymbol: false, lineStyle: { width: 1, color: "#8b98a9", type: "dashed" } },
      { name: "成交量", type: "bar", xAxisIndex: 1, yAxisIndex: 1, data: vols, itemStyle: { color: "#3a4a5f" } },
    ],
  }, true);
}

/* ================= 自选管理 ================= */

async function addStock() {
  const input = $("#add-input");
  const code = input.value.trim();
  if (!code) return;
  try {
    const res = await api.post("/api/watchlist", { code });
    if (res.code) {
      state.watchlist = res.watchlist;
      input.value = "";
      renderWatchlist();
      selectStock(res.code);
      refreshQuotes();
    } else if (res.error) {
      alert(res.error);
    }
  } catch (e) {
    alert("添加失败: " + e.message);
  }
}

async function removeStock(sym) {
  const res = await api.del("/api/watchlist?code=" + sym);
  state.watchlist = res.watchlist;
  if (state.selected === sym) state.selected = state.watchlist[0] || null;
  if (!state.selected) resetDetail();
  renderWatchlist();
  refreshQuotes();
}

/* ================= 报警 ================= */

function appendAlert(item) {
  const log = $("#alert-log");
  const div = document.createElement("div");
  div.className = item.level || "info";
  div.innerHTML = '<span class="ts">[' + (item.ts || "") + ']</span>' + escapeHtml(item.message);
  log.prepend(div);
  while (log.children.length > 100) log.removeChild(log.lastChild);
  if (state.notifying && "Notification" in window && Notification.permission === "granted") {
    try {
      new Notification("A股盯盘提醒", { body: item.message });
    } catch (e) {}
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function connectAlerts() {
  const es = new EventSource("/api/alert-stream");
  es.onmessage = (e) => {
    if (e.data && e.data.charAt(0) === ":") return;
    try {
      appendAlert(JSON.parse(e.data));
    } catch (err) {}
  };
  es.onerror = () => {};
}

/* ================= 股票排行 ================= */

let scanData = { market: [], top: [] };

async function doScan() {
  const metric = $("#metric-select").value;
  $("#screener-status").textContent = "正在扫描全市场...";
  $("#scan-btn").disabled = true;
  try {
    const minHits = metric === "overnight" ? $("#min-hits-select").value : "";
    const url = "/api/scan?metric=" + metric + "&n=100" + (minHits ? "&min_hits=" + minHits : "");
    const d = await api.get(url);
    scanData = d;
    renderScreener(metric);
    $("#screener-status").textContent = "共 " + (d.count || 0) + " 只，取前 " + (d.top || []).length + " 名";
  } catch (e) {
    $("#screener-status").textContent = "扫描失败: " + e.message;
  } finally {
    $("#scan-btn").disabled = false;
  }
}

function renderScreener(metric) {
  const top = scanData.top || [];
  const tbody = $("#screener-table tbody");
  tbody.innerHTML = "";
  const isScore = metric === "score";
  const isOvernight = metric === "overnight";
  const headers = $("#screener-table thead th");
  // 表头固定 11 列：排名|评分|代码|名称|现价|涨跌幅|换手率|量比|总市值|技术形态|所属板块
  // overnight 模式下第2列(评分)不适用，置空以免出现"有标题无数据"的列
  if (headers[1]) headers[1].textContent = isOvernight ? "" : "评分";
  if (headers[8]) headers[8].textContent = "总市值";
  if (headers[9]) headers[9].textContent = isOvernight ? "命中数" : "技术形态";
  if (headers[10]) headers[10].textContent = "所属板块";

  top.forEach((r, i) => {
    const tr = document.createElement("tr");
    const pct = r.change_pct || 0;
    const cls = pct > 0 ? "up" : pct < 0 ? "down" : "flat";
    let scoreCell = "", techCell = "", sectorCell = r.sector || "--";
    // 第9列统一显示总市值（亿），与表头"总市值"对应
    const mvCell = r.total_mv ? '<td>' + Math.round(r.total_mv) + "亿</td>" : "<td>--</td>";
    if (isScore) {
      scoreCell = r.score != null ? '<td class="col-yellow">' + r.score.toFixed(1) + "</td>" : "<td>--</td>";
      techCell = r.trend_structure != null ? '<td>' + r.trend_structure.toFixed(0) + "</td>" : "<td>--</td>";
    } else if (isOvernight) {
      const hit = r.cond_hit || 0;
      const missing = (r.conditions || []).map((c, j) => (c ? null : j)).filter((x) => x !== null)
        .map((j) => (screenerCondDesc[j] || "")).filter(Boolean);
      const hcls = hit === 7 ? "up" : hit >= 6 ? "col-yellow" : "col-blue";
      // 必须补上评分列的空 td，保持与表头 11 列对齐，否则数据列整体左移导致错位
      scoreCell = "<td></td>";
      techCell = '<td class="' + hcls + '" title="' + (missing.length ? "缺失: " + escapeHtml(missing.join("、")) : "全部 7 项满足") + '">' + hit + "/7</td>";
      sectorCell = r.sector || "--";
    } else {
      scoreCell = "<td></td>";
      techCell = r.trend_structure != null ? '<td>' + r.trend_structure.toFixed(0) + "</td>" : "<td>--</td>";
    }
    tr.innerHTML = `
      <td>${i + 1}</td>${scoreCell}
      <td>${r.code}</td>
      <td>${r.name}</td>
      <td class="${cls}">${r.price ? r.price.toFixed(2) : "--"}</td>
      <td class="${cls}">${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%</td>
      <td class="col-blue">${r.turnover_rate != null ? r.turnover_rate.toFixed(2) + "%" : "--"}</td>
      <td class="col-yellow">${r.volume_ratio != null ? r.volume_ratio.toFixed(2) : "--"}</td>
      ${mvCell}${techCell}<td>${sectorCell}</td>`;
    tr.addEventListener("dblclick", () => addFromScreener(r));
    tbody.appendChild(tr);
  });
}

async function addFromScreener(r) {
  const sym = r.symbol || (r.code ? (r.code.startsWith("6") || r.code.startsWith("9") || r.code.startsWith("5") ? "sh" : "sz") + r.code : "");
  if (!sym) return;
  const res = await api.post("/api/watchlist", { code: sym });
  if (res.code) {
    state.watchlist = res.watchlist;
    switchTab("watch");
    renderWatchlist();
    selectStock(res.code);
    refreshQuotes();
    $("#watch-status").textContent = "已加入自选: " + res.code;
  }
}

/* ================= 页面控制 ================= */

function switchTab(name) {
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  $$(".tab-page").forEach((p) => p.classList.toggle("active", p.id === "tab-" + name));
  if (name === "watch") {
    loadWatchlist();
  } else {
    doScan();
  }
}

function updateClock() {
  const now = new Date();
  const p = (n) => String(n).padStart(2, "0");
  $("#clock").textContent = now.getFullYear() + "-" + p(now.getMonth() + 1) + "-" + p(now.getDate())
    + " " + p(now.getHours()) + ":" + p(now.getMinutes()) + ":" + p(now.getSeconds());
}

/* ================= 事件绑定 ================= */

function bindEvents() {
  $$(".tab").forEach((t) => t.addEventListener("click", () => switchTab(t.dataset.tab)));
  $("#add-btn").addEventListener("click", addStock);
  $("#add-input").addEventListener("keydown", (e) => { if (e.key === "Enter") addStock(); });
  $("#refresh-interval").addEventListener("change", (e) => {
    state.refreshMs = parseInt(e.target.value, 10) * 1000;
    restartTimer();
  });
  $("#notify-toggle").addEventListener("change", (e) => {
    state.notifying = e.target.checked;
    if (state.notifying && "Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  });
  $$("#chart-mode-bar .btn").forEach((b) => {
    b.addEventListener("click", () => {
      $$("#chart-mode-bar .btn").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      state.chartMode = b.dataset.chart;
      if (state.selected) {
        if (state.chartMode === "kline") loadKline(state.selected);
        else loadMinute(state.selected);
      }
    });
  });
  $("#metric-select").addEventListener("change", (e) => {
    $("#min-hits-wrap").style.display = e.target.value === "overnight" ? "" : "none";
    doScan();
  });
  $("#min-hits-select").addEventListener("change", doScan);
  $("#scan-btn").addEventListener("click", doScan);
  const ffPanel = $("#fundflow-panel");
  if (ffPanel) {
    ffPanel.addEventListener("mouseenter", showFundflowPopup);
    ffPanel.addEventListener("mouseleave", hideFundflowPopup);
  }
  window.addEventListener("resize", () => {
    Object.values(state.charts).forEach((c) => c && c.resize());
  });
}

function restartTimer() {
  if (state.timer) clearInterval(state.timer);
  state.timer = setInterval(refreshQuotes, state.refreshMs);
}

/* ================= 启动 ================= */

async function init() {
  bindEvents();
  updateClock();
  setInterval(updateClock, 1000);
  connectAlerts();
  restartTimer();
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
  }
  await loadWatchlist();
  switchTab("watch");
}

init();
