#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
app.py —— A股实时盯盘助手 · 网页版后端（Flask）

复用桌面版的数据层模块（stkquote / kline / minute / indicators / alerts /
fundflow / screener），通过 REST API + SSE 提供给前端。

运行：
    python3 app.py            # 默认 127.0.0.1:8000
    python3 app.py --host 0.0.0.0 --port 8080
"""

import argparse
import json
import os
import queue
import threading
import time

from flask import Flask, Response, jsonify, request, send_from_directory

import stkquote
import kline as kline_mod
import minute as minute_mod
import indicators
import alerts as alerts_mod
import fundflow as fundflow_mod
import screener

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/static")

# ------------------------------------------------------------------
# 自选股配置（config.json）
# ------------------------------------------------------------------
_config_lock = threading.Lock()


def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"watchlist": []}


def save_config(cfg):
    tmp = CONFIG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CONFIG_FILE)


def get_watchlist():
    return load_config().get("watchlist", [])


def add_watchlist(code):
    code = stkquote.normalize_code(code)
    with _config_lock:
        cfg = load_config()
        wl = cfg.setdefault("watchlist", [])
        if code not in wl:
            wl.append(code)
        save_config(cfg)
    return code


def remove_watchlist(code):
    code = stkquote.normalize_code(code)
    with _config_lock:
        cfg = load_config()
        wl = cfg.get("watchlist", [])
        if code in wl:
            wl.remove(code)
        save_config(cfg)
    return code


# ------------------------------------------------------------------
# 全市场扫描缓存（扫描较慢，缓存 60s，避免频繁触发）
# ------------------------------------------------------------------
_scan_lock = threading.Lock()
_scan_cache = {"ts": 0, "data": [], "sector": {}}
SCAN_TTL = 60


def _get_market_data():
    now = time.time()
    if now - _scan_cache["ts"] < SCAN_TTL and _scan_cache["data"]:
        return _scan_cache["data"], _scan_cache["sector"]
    with _scan_lock:
        now = time.time()
        if now - _scan_cache["ts"] < SCAN_TTL and _scan_cache["data"]:
            return _scan_cache["data"], _scan_cache["sector"]
        market = screener.scan_market()
        sector = screener._load_sector_map()
        if not sector:
            try:
                sector = screener.build_sector_map()
                screener._save_sector_map(sector)
            except Exception:
                sector = {}
        _scan_cache.update({"ts": time.time(), "data": market, "sector": sector})
        return market, sector


# ------------------------------------------------------------------
# 报警引擎（SSE 推送）
# ------------------------------------------------------------------
_alert_queue = queue.Queue(maxsize=200)
_alert_engine = None


def _default_rules(code):
    """网页版默认规则：涨跌幅 ±5% + 放量异动 + RSI 超买超卖。"""
    return [
        ("change_pct", {"up": 5, "down": -5}),
        ("volume", {}),
        ("rsi", {"overbought": 70, "oversold": 30}),
    ]


def _alert_worker():
    """后台线程：周期检查自选股行情，命中规则后推送到 SSE 队列。"""
    global _alert_engine
    engine = alerts_mod.AlertEngine(
        notifier=lambda r: _safe_put({
            "type": "alert",
            "level": r.level,
            "message": r.message,
            "ts": r.ts,
        }))
    _alert_engine = engine

    # 指标缓存：code -> indicators.summarize 结果，避免每轮都拉K线
    _ind_cache = {}

    while True:
        try:
            codes = get_watchlist()
            if not codes:
                time.sleep(5)
                continue
            quotes = stkquote.fetch_quotes(codes)
            # 定时刷新指标缓存（每 ~2 分钟，因为指标基于日K线，变化慢）
            need_refresh = (int(time.time()) // 120) != getattr(_alert_worker, "_last_cycle", -1)
            _alert_worker._last_cycle = int(time.time()) // 120

            for code in codes:
                quote = quotes.get(code[2:]) or quotes.get(code) or {}
                if not quote:
                    continue
                ind = None
                if need_refresh:
                    try:
                        kl = kline_mod.fetch_kline(code, count=120)
                        if kl:
                            ind = indicators.summarize(kl)
                            _ind_cache[code] = ind
                    except Exception:
                        pass
                else:
                    ind = _ind_cache.get(code)
                # 行情里附带的量比/换手也能触发 volume 规则
                if ind is None:
                    ind = {"volume_anomaly": (quote.get("volume_ratio") or 0) > 2.0,
                           "volume_ratio": quote.get("volume_ratio") or 0,
                           "rsi6": None}
                engine.set_rules(code, _default_rules(code))
                engine.check(code[2:] if code.startswith(("sh", "sz")) else code,
                             quote, indicators=ind)
        except Exception as e:
            print(f"[alert] 报警检查异常: {e}")
        time.sleep(5)


def _safe_put(item):
    try:
        _alert_queue.put_nowait(item)
    except queue.Full:
        try:
            _alert_queue.get_nowait()
        except queue.Empty:
            pass
        try:
            _alert_queue.put_nowait(item)
        except queue.Full:
            pass


def _start_background():
    t = threading.Thread(target=_alert_worker, daemon=True)
    t.start()


# ------------------------------------------------------------------
# 页面 & 静态资源
# ------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


# ------------------------------------------------------------------
# API: 行情
# ------------------------------------------------------------------
@app.route("/api/quotes")
def api_quotes():
    codes = request.args.get("codes", "")
    if not codes:
        return jsonify([])
    symbols = [stkquote.normalize_code(c) for c in codes.split(",") if c.strip()]
    quotes = stkquote.fetch_quotes(symbols)
    # 统一返回带 symbol 的列表
    result = []
    for sym in symbols:
        q = quotes.get(sym[2:]) or quotes.get(sym)
        if q:
            q = dict(q)
            q["symbol"] = sym
            result.append(q)
    return jsonify(result)


# ------------------------------------------------------------------
# API: K线 / 分时
# ------------------------------------------------------------------
@app.route("/api/kline")
def api_kline():
    code = stkquote.normalize_code(request.args.get("code", ""))
    try:
        count = int(request.args.get("count", 120))
    except ValueError:
        count = 120
    kl = kline_mod.fetch_kline(code, count=count)
    ma_data = indicators.ma(kl) if kl else {}
    macd_data = indicators.macd(kl) if kl else {}
    return jsonify({
        "code": code,
        "klines": kl,
        "ma": {str(k): v for k, v in ma_data.items()},
        "macd": macd_data,
    })


@app.route("/api/minute")
def api_minute():
    code = stkquote.normalize_code(request.args.get("code", ""))
    try:
        data = minute_mod.fetch_minute(code)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify(data)


@app.route("/api/indicators")
def api_indicators():
    code = stkquote.normalize_code(request.args.get("code", ""))
    try:
        count = int(request.args.get("count", 120))
    except ValueError:
        count = 120
    kl = kline_mod.fetch_kline(code, count=count)
    if not kl:
        return jsonify({"error": "获取K线失败"}), 500
    s = indicators.summarize(kl)
    ts = indicators.technical_score(kl)
    return jsonify({"code": code, **s, "tech_score": ts["score"],
                    "tech_bullish": ts["bullish"],
                    "tech_parts": {k: ts[k] for k in ("ma_align", "price_vs_ma",
                                                       "macd", "kdj", "rsi")}})


# ------------------------------------------------------------------
# API: 主力资金
# ------------------------------------------------------------------
@app.route("/api/fundflow")
def api_fundflow():
    code = stkquote.normalize_code(request.args.get("code", ""))
    quote = stkquote.fetch_quotes([code]).get(code[2:], {})
    amt = quote.get("amount")
    ff = fundflow_mod.fetch_main_fundflow(code, amount_wan=amt)
    if not ff:
        return jsonify({"error": "无资金流数据"}), 404
    ff["name"] = quote.get("name", "")
    ff["symbol"] = code
    return jsonify(ff)


@app.route("/api/fundflow/history")
def api_fundflow_history():
    code = stkquote.normalize_code(request.args.get("code", ""))
    try:
        days = int(request.args.get("days", 20))
    except ValueError:
        days = 20
    rows = fundflow_mod.fetch_fundflow_history(code, days=days)
    return jsonify({"symbol": code, "days": days, "rows": rows})


# ------------------------------------------------------------------
# API: 自选股管理
# ------------------------------------------------------------------
@app.route("/api/watchlist", methods=["GET"])
def api_watchlist_get():
    return jsonify({"watchlist": get_watchlist()})


@app.route("/api/watchlist", methods=["POST"])
def api_watchlist_add():
    data = request.get_json(silent=True) or {}
    code = data.get("code", "")
    if not code:
        return jsonify({"error": "缺少 code"}), 400
    try:
        norm = add_watchlist(code)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"code": norm, "watchlist": get_watchlist()})


@app.route("/api/watchlist", methods=["DELETE"])
def api_watchlist_remove():
    code = request.args.get("code", "")
    if not code:
        return jsonify({"error": "缺少 code"}), 400
    try:
        norm = remove_watchlist(code)
    except ValueError:
        norm = code
    return jsonify({"code": norm, "watchlist": get_watchlist()})


# ------------------------------------------------------------------
# API: 全市场扫描 / 排行
# ------------------------------------------------------------------
@app.route("/api/scan")
def api_scan():
    metric = request.args.get("metric", "lb")
    try:
        n = int(request.args.get("n", 100))
    except ValueError:
        n = 100
    try:
        min_hits = int(request.args.get("min_hits", 0)) or None
    except ValueError:
        min_hits = None
    market, sector = _get_market_data()
    if metric == "score":
        top = screener.top_by_score(market, n, sector)
        return jsonify({"metric": metric, "count": len(market), "top": top})
    if metric == "overnight":
        top = screener.overnight_hold(market, sector, require_all=False,
                                      min_hits=min_hits, max_results=n)
        return jsonify({"metric": metric, "count": len(market), "top": top})
    top = screener.top_by_metric(market, metric, n, sector)
    return jsonify({"metric": metric, "count": len(market), "top": top})


# ------------------------------------------------------------------
# API: 报警 SSE 推送
# ------------------------------------------------------------------
@app.route("/api/alert-stream")
def api_alert_stream():
    def gen():
        while True:
            try:
                item = _alert_queue.get(timeout=15)
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
            except queue.Empty:
                yield ": keep-alive\n\n"
    return Response(gen(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


# ------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="A股实时盯盘助手 网页版")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    _start_background()
    print(f"* 网页版已启动: http://{args.host}:{args.port}")
    print("* 按 Ctrl+C 停止")
    app.run(host=args.host, port=args.port, debug=args.debug, threaded=True)
