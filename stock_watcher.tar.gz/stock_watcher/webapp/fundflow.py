# -*- coding: utf-8 -*-
"""
fundflow.py —— A股主力资金流向抓取模块（东方财富免费资金流接口）。

数据来源（按优先级依次尝试）：
    1. https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get （完整6字段）
    2. https://push2.eastmoney.com/api/qt/stock/fflow/kline/get
    3. https://datacenter-web.eastmoney.com/api/data/v1/get （RPT_DMSK_TS_STOCKNEW，
       稳定备用；仅含主力/超大单/大单，中单/小单返回 None）

返回当日买卖驱动资金净流入：
    - 主力净流入（超大单 + 大单）
    - 超大单 / 大单 / 中单 / 小单 各自的净流入（正=净流入，负=净流出）
    - 主力净流入占比（相对当日成交额）

push2his klines 每行格式（升序）：
    "时间, 主力净流入, 小单净流入, 中单净流入, 大单净流入, 超大单净流入"（单位：元）
datacenter 字段：
    PRIME_INFLOW 主力净流入 / SUPERDEAL_* 超大单 / BIGDEAL_* 大单（单位：元）
用法：
    from fundflow import fetch_main_fundflow
    ff = fetch_main_fundflow("sh600519", amount_wan=242870)   # amount_wan 为当日成交额(万元)
"""

import json
import os
import urllib.request

FFLOW_URLS = [
    ("https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?"
     "lmt=1&klt=101&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56&secid={secid}"),
    ("https://push2.eastmoney.com/api/qt/stock/fflow/kline/get?"
     "lmt=1&klt=1&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56&secid={secid}"),
]
HIST_FFLOW_URL = ("https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?"
                  "lmt={days}&klt=101&fields1=f1,f2,f3,f7"
                  "&fields2=f51,f52,f53,f54,f55,f56&secid={secid}")
DATACENTER_URL = ("https://datacenter-web.eastmoney.com/api/data/v1/get?"
                  "reportName=RPT_DMSK_TS_STOCKNEW&columns=ALL&"
                  "filter=(SECURITY_CODE%3D%22{code}%22)&pageNumber=1&pageSize=1")

HIST_CACHE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "fundflow_history.json")
_hist_cache_lock = __import__("threading").Lock()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://quote.eastmoney.com/",
}


def to_secid(symbol: str) -> str:
    """把 sh600519 / sz300750 转成东财 secid（1.=沪, 0.=深）。"""
    symbol = symbol.strip().lower()
    if symbol.startswith("sh"):
        return "1." + symbol[2:]
    if symbol.startswith("sz"):
        return "0." + symbol[2:]
    digits = symbol.split(".")[-1] or symbol
    if digits.startswith(("6", "9", "5")):
        return "1." + digits
    return "0." + digits


def _fmt_wan(v):
    """元 -> 万元，保留整数。"""
    return round(v / 10000.0)


def _fetch_from_kline(secid: str):
    """尝试 push2/push2his 资金流 kline 接口，返回原始行解析后的 dict 或 None。"""
    for url_tpl in FFLOW_URLS:
        url = url_tpl.format(secid=secid)
        req = urllib.request.Request(url, headers=HEADERS)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                obj = json.loads(resp.read().decode("utf-8"))
            data = obj.get("data") or {}
            klines = data.get("klines") or []
        except Exception:
            continue
        if not klines:
            continue
        last = klines[-1]
        parts = last.split(",")
        if len(parts) < 6:
            continue
        ts = parts[0].split(" ")[-1] if " " in parts[0] else parts[0]
        try:
            main_net = float(parts[1])
            small = float(parts[2])
            medium = float(parts[3])
            large = float(parts[4])
            super_large = float(parts[5])
        except (ValueError, IndexError):
            continue
        return {
            "main_net": main_net, "super_large": super_large, "large": large,
            "medium": medium, "small": small, "ts": ts,
        }
    return None


def _fetch_history_from_kline(secid: str, days: int = 20):
    """用 push2his daykline 抓取最近 days 个交易日资金流（升序）。

    返回 list[dict] 或 None：
        [{ 'date': '2026-09-22', 'main_net': float, 'super_large': float,
           'large': float, 'medium': float, 'small': float }, ...]
    """
    url = HIST_FFLOW_URL.format(days=days, secid=secid)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            obj = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None
    data = obj.get("data") or {}
    klines = data.get("klines") or []
    if not klines:
        return None
    rows = []
    for line in klines:
        parts = line.split(",")
        if len(parts) < 6:
            continue
        try:
            rows.append({
                "date": parts[0][:10],
                "main_net": float(parts[1]),
                "small": float(parts[2]),
                "medium": float(parts[3]),
                "large": float(parts[4]),
                "super_large": float(parts[5]),
            })
        except (ValueError, IndexError):
            continue
    return rows or None


def _load_hist_cache():
    try:
        with open(HIST_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_hist_cache(cache):
    with _hist_cache_lock:
        tmp = HIST_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
        os.replace(tmp, HIST_CACHE_FILE)


def fetch_fundflow_history(symbol: str, days: int = 20) -> list:
    """抓取单只股票最近 days 个交易日的主力资金流向（升序）。

    数据源优先级：
        1. push2his daykline（完整五档，含主力净占比所需基础数据）
        2. 本地累积缓存 fundflow_history.json（每日增量累积，随使用天数增加）
        3. datacenter 当日报表（仅有当天一条）

    返回 list[dict]，每项：
        { 'date', 'main_net'(元), 'super_large'(元), 'large'(元),
          'medium'(元), 'small'(元) }
    """
    secid = to_secid(symbol)
    rows = _fetch_history_from_kline(secid, days)

    # 无论走哪个源，都写入本地累积缓存
    cache = _load_hist_cache()
    bucket = cache.setdefault(symbol, {})
    if rows:
        for r in rows:
            bucket[r["date"]] = {k: r[k] for k in
                                 ("main_net", "super_large", "large", "medium", "small")}
        _save_hist_cache(cache)

    if not rows:
        cached = sorted(bucket.items(), key=lambda kv: kv[0])
        rows = [dict({"date": d}, **v) for d, v in cached[-days:]]

    if rows:
        return rows[-days:]

    # 最后回退：datacenter 当日（同时写入累积缓存）
    d = _fetch_from_datacenter(secid)
    if d:
        bucket[d["ts"]] = {k: d[k] for k in
                           ("main_net", "super_large", "large", "medium", "small")}
        _save_hist_cache(cache)
        return [dict({"date": d["ts"]}, **bucket[d["ts"]])]
    return []


def _fetch_from_datacenter(secid: str):
    """回退用 datacenter 报表，返回 dict（中单/小单为 None）或 None。"""
    code = secid.split(".")[-1]
    url = DATACENTER_URL.format(code=code)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            obj = json.loads(resp.read().decode("utf-8"))
        data = ((obj.get("result") or {}).get("data") or [])
    except Exception:
        return None
    if not data:
        return None
    row = data[0]
    try:
        main_net = float(row.get("PRIME_INFLOW") or 0)
        super_large = float(row.get("SUPERDEAL_INFLOW") or 0) - float(row.get("SUPERDEAL_OUTFLOW") or 0)
        large = float(row.get("BIGDEAL_INFLOW") or 0) - float(row.get("BIGDEAL_OUTFLOW") or 0)
    except (ValueError, TypeError):
        return None
    return {
        "main_net": main_net, "super_large": super_large, "large": large,
        "medium": None, "small": None,
        "ts": str(row.get("TRADE_DATE", ""))[:10],
    }


def fetch_main_fundflow(symbol: str, amount_wan: float = None) -> dict:
    """抓取单只股票当日主力资金流向。

    参数：
        symbol      —— 规范化代码，如 'sh600519'
        amount_wan  —— 当日成交额（万元），用于计算主力净占比；可传 None 跳过
    返回 dict（全部数据源失败时返回空 dict）：
        {
            'main_netflow': float,    # 主力净流入（万元）
            'super_large': float,     # 超大单净流入（万元）
            'large': float,           # 大单净流入（万元）
            'medium': float,          # 中单净流入（万元，缺失时 None）
            'small': float,           # 小单净流入（万元，缺失时 None）
            'main_net_ratio': float,  # 主力净流入占比（%）
            'ts': '2026-09-22',       # 数据时间
        }
    """
    secid = to_secid(symbol)
    data = _fetch_from_kline(secid) or _fetch_from_datacenter(secid)
    if not data:
        return {}

    main_net_ratio = None
    if amount_wan:
        turnover_yuan = amount_wan * 10000.0
        if turnover_yuan > 0:
            main_net_ratio = round(data["main_net"] / turnover_yuan * 100.0, 2)

    return {
        "main_netflow": _fmt_wan(data["main_net"]),
        "super_large": _fmt_wan(data["super_large"]) if data["super_large"] is not None else None,
        "large": _fmt_wan(data["large"]) if data["large"] is not None else None,
        "medium": _fmt_wan(data["medium"]) if data["medium"] is not None else None,
        "small": _fmt_wan(data["small"]) if data["small"] is not None else None,
        "main_net_ratio": main_net_ratio,
        "ts": data["ts"],
    }


if __name__ == "__main__":
    from stkquote import fetch_quotes
    for sym in ("sh600519", "sz300750"):
        q = fetch_quotes([sym]).get(sym[2:], {})
        amt = q.get("amount")
        ff = fetch_main_fundflow(sym, amount_wan=amt)
        print(f"\n{sym} 成交额(万)={amt}")
        if not ff:
            print("  无资金流数据")
        else:
            print(f"  主力净流入: {ff['main_netflow']} 万  占比: {ff['main_net_ratio']}%")
            print(f"  超大单 {ff['super_large']}  大单 {ff['large']}  "
                  f"中单 {ff['medium']}  小单 {ff['small']} (万)  时间 {ff['ts']}")
