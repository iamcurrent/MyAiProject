# -*- coding: utf-8 -*-
"""
fundflow.py —— A股主力资金流向抓取模块（基于东方财富免费资金流接口）。

数据来源：https://push2.eastmoney.com/api/qt/stock/fflow/kline/get （免费、无需 token）
返回当日买卖驱动资金净流入：
    - 主力净流入（超大单 + 大单）
    - 超大单 / 大单 / 中单 / 小单 各自的净流入（正=净流入，负=净流出）
    - 主力净流入占比（相对当日成交额）

接口 klines 每行格式（升序）：
    "时间, 主力净流入, 小单净流入, 中单净流入, 大单净流入, 超大单净流入"（单位：元）
用法：
    from fundflow import fetch_main_fundflow
    ff = fetch_main_fundflow("sh600519", amount_wan=242870)   # amount_wan 为当日成交额(万元)
"""

import urllib.request

FFLOW_URL = ("https://push2.eastmoney.com/api/qt/stock/fflow/kline/get?"
             "lmt=1&klt=1&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56&secid={secid}")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://quote.eastmoney.com/",
}


def to_secid(symbol: str) -> str:
    """把 sh600519 / sz300750 转成东财 secid（1.=沪, 0.=深）。"""
    symbol = symbol.strip().lower()
    if symbol.startswith("sh"):
        return "1." + symbol[2:]
    if symbol.startswith("sz"):
        return "0." + symbol[2:]
    # 无前缀时按数字段推断
    digits = symbol.split(".")[-1] or symbol
    if digits.startswith(("6", "9", "5")):
        return "1." + digits
    return "0." + digits


def _fmt_wan(v):
    """元 -> 万元，保留整数。"""
    return round(v / 10000.0)


def fetch_main_fundflow(symbol: str, amount_wan: float = None) -> dict:
    """抓取单只股票当日主力资金流向。

    参数：
        symbol      —— 规范化代码，如 'sh600519'
        amount_wan  —— 当日成交额（万元），用于计算主力净占比；可传 None 跳过
    返回 dict（失败返回空 dict）：
        {
            'main_netflow': float,    # 主力净流入（万元）
            'super_large': float,     # 超大单净流入（万元）
            'large': float,           # 大单净流入（万元）
            'medium': float,          # 中单净流入（万元）
            'small': float,           # 小单净流入（万元）
            'main_net_ratio': float,  # 主力净流入占比（%）
            'ts': '15:00',            # 数据时间
        }
    """
    secid = to_secid(symbol)
    url = FFLOW_URL.format(secid=secid)
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            import json
            obj = json.loads(resp.read().decode("utf-8"))
        data = obj.get("data") or {}
        klines = data.get("klines") or []
    except Exception:
        return {}

    if not klines:
        return {}
    last = klines[-1]
    parts = last.split(",")
    if len(parts) < 6:
        return {}
    ts = parts[0].split(" ")[-1] if " " in parts[0] else parts[0]
    try:
        main_net = float(parts[1])      # 主力净流入（元）
        small = float(parts[2])         # 小单
        medium = float(parts[3])        # 中单
        large = float(parts[4])         # 大单
        super_large = float(parts[5])   # 超大单
    except (ValueError, IndexError):
        return {}

    main_net_ratio = None
    if amount_wan:
        turnover_yuan = amount_wan * 10000.0
        if turnover_yuan > 0:
            main_net_ratio = round(main_net / turnover_yuan * 100.0, 2)

    return {
        "main_netflow": _fmt_wan(main_net),
        "super_large": _fmt_wan(super_large),
        "large": _fmt_wan(large),
        "medium": _fmt_wan(medium),
        "small": _fmt_wan(small),
        "main_net_ratio": main_net_ratio,
        "ts": ts,
    }


if __name__ == "__main__":
    from stkquote import fetch_quotes
    for sym in ("sh600519", "sz300750"):
        q = fetch_quotes([sym]).get(sym[2:], {})
        amt = q.get("amount")
        ff = fetch_main_fundflow(sym, amount_wan=amt)
        print(f"\n{sym} 成交额(万)={amt}")
        if not ff:
            print("  无资金流数据")
        else:
            print(f"  主力净流入: {ff['main_netflow']} 万  占比: {ff['main_net_ratio']}%")
            print(f"  超大单 {ff['super_large']}  大单 {ff['large']}  "
                  f"中单 {ff['medium']}  小单 {ff['small']} (万)  时间 {ff['ts']}")
