# -*- coding: utf-8 -*-
"""
ui_screener.py —— "股票排行"选股界面。

功能：
    - 按量比 / 换手率 / 涨跌幅 三种维度排序筛选前 100 名
    - 展示列：排名、代码、名称、现价、涨跌幅、换手率、量比、所属板块
    - 全市场扫描在后台线程执行，结果缓存，三榜秒切
"""

import threading
import time

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QBrush, QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QPushButton, QComboBox, QGroupBox, QTextEdit,
)

import screener

RED = QColor(230, 60, 60)
GREEN = QColor(30, 160, 90)


class ScreenerPanel(QWidget):
    """股票排行面板。"""

    # 双击某行时发出，携带该股 symbol（如 'sh600519'），由主窗口加入盯盘
    add_to_watchlist = pyqtSignal(str)

    METRICS = [
        ("lb", "按量比"),
        ("hsl", "按换手率"),
        ("zdf", "按涨跌幅"),
        ("score", "按综合评分"),
        ("overnight", "一夜持股"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.market_data = []      # 全市场快照
        self.sector_map = {}
        self.current_metric = "lb"
        self.refreshing = False
        self._current_rows = []    # 当前表格展示的记录（供双击加入盯盘）

        self._build_ui()
        # 首次自动刷新
        self.refresh()

    # ---------- UI ----------

    def _build_ui(self):
        root = QVBoxLayout(self)

        bar = QHBoxLayout()
        bar.addWidget(QLabel("排行维度:"))
        self.metric_combo = QComboBox()
        for key, label in self.METRICS:
            self.metric_combo.addItem(label, key)
        self.metric_combo.currentIndexChanged.connect(self._on_metric_change)
        bar.addWidget(self.metric_combo)

        # 一夜持股：最低命中条数选择（默认 ≥5）
        bar.addSpacing(12)
        bar.addWidget(QLabel("最低命中:"))
        self.min_hits_combo = QComboBox()
        for label, val in [("≥5条", 5), ("≥6条", 6), ("全部7条", 7)]:
            self.min_hits_combo.addItem(label, val)
        self.min_hits_combo.setCurrentIndex(0)
        self.min_hits_combo.currentIndexChanged.connect(self._on_metric_change)
        self.min_hits_combo.setVisible(False)
        bar.addWidget(self.min_hits_combo)

        bar.addSpacing(12)
        self.status_label = QLabel("就绪")
        bar.addWidget(self.status_label)
        bar.addStretch(1)

        refresh_btn = QPushButton("刷新数据")
        refresh_btn.clicked.connect(self.refresh)
        bar.addWidget(refresh_btn)
        root.addLayout(bar)

        # 排名表（11列；综合评分模式显示"评分"与"近5日"，其余模式隐藏）
        self.table = QTableWidget(0, 11)
        self.table.setHorizontalHeaderLabels(
            ["排名", "评分", "代码", "名称", "现价", "涨跌幅",
             "换手率", "量比", "近5日", "技术形态", "所属板块"])
        # 默认隐藏 评分 和 近5日 两列（综合评分模式时显示）
        self.table.setColumnHidden(1, True)
        self.table.setColumnHidden(8, True)
        self.table.setColumnHidden(9, True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        # 允许小窗口时列收缩（Interactive 而非 Fixed），避免固定总宽撑爆窗口
        for i, w in enumerate([44, 52, 64, 96, 70, 76, 70, 60, 66, 66, 70]):
            header.setSectionResizeMode(i, QHeaderView.Interactive)
            self.table.setColumnWidth(i, w)
        self.table.horizontalHeader().setMinimumSectionSize(48)
        self.table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel)
        # 双击某行 -> 加入盯盘
        self.table.doubleClicked.connect(self._on_row_double_clicked)
        root.addWidget(self.table, 1)

        tip = QLabel("全市场扫描约需 2-3 秒，结果自动缓存，切换维度即时刷新；"
                     "综合评分综合考量成交额、量比、换手率、近期表现与技术形态"
                     "（由 5/10/20 日涨跌幅结构近似均线趋势）；"
                     "双击某行**加入盯盘**，即可在自选盯盘页持续监控")
        tip.setStyleSheet("color:#888;font-size:11px;")
        root.addWidget(tip)

    # ---------- 数据 ----------

    def refresh(self):
        if self.refreshing:
            return
        self.refreshing = True
        self.status_label.setText("正在扫描全市场...")
        self.table.setRowCount(0)
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            market = screener.scan_market()
            sector = screener._load_sector_map()
            if not sector:
                try:
                    sector = screener.build_sector_map()
                    screener._save_sector_map(sector)
                except Exception:
                    sector = {}
            self.market_data = market
            self.sector_map = sector
        except Exception as e:
            self._post_status(f"扫描失败: {e}")
            self.refreshing = False
            return
        self._post_status(f"已加载 {len(market)} 只股票，"
                          f"板块覆盖 {len(sector)} 只，耗时 就绪")
        # 用 QTimer 确保回到 UI 线程刷新表格
        QTimer.singleShot(0, self._render_table)

    def _render_table(self):
        self.refreshing = False
        metric = self.current_metric
        is_overnight = (metric == "overnight")
        if metric == "score":
            top = screener.top_by_score(self.market_data, 100, self.sector_map)
        elif is_overnight:
            min_hits = self.min_hits_combo.itemData(self.min_hits_combo.currentIndex())
            top = screener.overnight_hold(self.market_data, self.sector_map,
                                          require_all=False, min_hits=min_hits,
                                          max_results=100)
        else:
            top = screener.top_by_metric(self.market_data, metric, 100,
                                         self.sector_map)
        is_score = (metric == "score")
        self.table.setColumnHidden(1, not is_score)   # 评分列
        self.table.setColumnHidden(8, not is_score)   # 近5日列
        self.table.setColumnHidden(9, not is_score)   # 技术形态列
        # 一夜持股模式：隐藏"评分/近5日"；"技术形态"列显示命中数、
        # "所属板块"列显示流通市值，故动态改表头
        self.min_hits_combo.setVisible(is_overnight)
        # 评分列/近5日列仅在综合评分模式显示（其余模式含一夜持股均隐藏）
        self.table.setColumnHidden(1, not is_score)
        self.table.setColumnHidden(8, not is_score)
        # 技术形态列在综合评分模式显示"技术形态分"、一夜持股显示"命中数"
        self.table.setColumnHidden(9, not is_score and not is_overnight)
        hdr_item_9 = QTableWidgetItem("命中数" if is_overnight else "技术形态")
        hdr_item_10 = QTableWidgetItem("流通市值" if is_overnight else "所属板块")
        self.table.setHorizontalHeaderItem(9, hdr_item_9)
        self.table.setHorizontalHeaderItem(10, hdr_item_10)
        # 记录当前展示的行记录，供"双击加入盯盘"取 symbol
        self._current_rows = top
        if is_overnight:
            self._fill_overnight(top)
        else:
            self._fill_table(top)
        self.status_label.setText(
            f"共 {len(self.market_data)} 只，{self.metric_combo.currentText()}"
            f" 取前 {len(top)} 名")

    def _fill_table(self, records):
        self.table.setRowCount(len(records))
        for i, r in enumerate(records, 1):
            up = r["change_pct"] >= 0
            color = RED if up else GREEN
            has_score = "score" in r
            d5 = r.get("zdf_d5")
            trend = r.get("trend_structure")
            cells = [
                str(i),
                f"{r['score']:.1f}" if has_score else "",
                r["code"],
                r["name"],
                f"{r['price']:.2f}" if r["price"] else "--",
                f"{r['change_pct']:+.2f}%",
                f"{r['turnover_rate']:.2f}%",
                f"{r['volume_ratio']:.2f}",
                (f"{d5:+.2f}%" if d5 is not None else "--"),
                (f"{trend:.0f}" if (has_score and trend is not None) else ""),
                r["sector"],
            ]
            # 数字列着色
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignCenter)
                if col in (4, 5):       # 现价、涨跌幅用涨跌色
                    item.setForeground(QBrush(color))
                elif col == 1:          # 评分
                    item.setForeground(QBrush(QColor(255, 240, 120)))
                    item.setFont(QFont("Sans Serif", 9, QFont.Bold))
                elif col == 6:          # 换手率
                    item.setForeground(QBrush(QColor(90, 170, 255)))
                elif col == 7:          # 量比
                    item.setForeground(QBrush(QColor(255, 200, 60)))
                elif col == 8:          # 近5日
                    item.setForeground(QBrush(RED if (d5 or 0) >= 0 else GREEN))
                elif col == 9:          # 技术形态分（多头橙红/空头墨绿）
                    if trend is not None:
                        item.setForeground(QBrush(
                            RED if trend >= 60 else
                            (QColor(255, 200, 60) if trend >= 40 else GREEN)))
                self.table.setItem(i - 1, col, item)

    def _fill_overnight(self, records):
        """一夜持股模式填充：在"技术形态"列显示命中数 N/7，tooltip 展示缺失条件。"""
        self.table.setRowCount(len(records))
        for i, r in enumerate(records, 1):
            up = r["change_pct"] >= 0
            color = RED if up else GREEN
            cond = r.get("conditions", [])
            hit = r.get("cond_hit", 0)
            missing = [screener.OVERNIGHT_COND_DESC[j]
                       for j, c in enumerate(cond) if not c]
            cells = [
                str(i),
                "",
                r["code"],
                r["name"],
                f"{r['price']:.2f}" if r["price"] else "--",
                f"{r['change_pct']:+.2f}%",
                f"{r['turnover_rate']:.2f}%",
                f"{r['volume_ratio']:.2f}",
                "",
                f"{hit}/7",
                (f"{r['float_mv']:.0f}亿" if r.get("float_mv") else "--"),
            ]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignCenter)
                if col in (4, 5):       # 现价、涨跌幅
                    item.setForeground(QBrush(color))
                elif col == 6:          # 换手率
                    item.setForeground(QBrush(QColor(90, 170, 255)))
                elif col == 7:          # 量比
                    item.setForeground(QBrush(QColor(255, 200, 60)))
                elif col == 9:          # 命中数
                    item.setForeground(QBrush(
                        RED if hit == 7 else
                        (QColor(255, 200, 60) if hit >= 6 else QColor(140, 140, 255))))
                    item.setFont(QFont("Sans Serif", 9, QFont.Bold))
                    if missing:
                        item.setToolTip("缺失条件: " + "、".join(missing))
                    else:
                        item.setToolTip("全部 7 项条件均满足")
                elif col == 10:         # 流通市值
                    item.setForeground(QBrush(QColor(190, 190, 190)))
                self.table.setItem(i - 1, col, item)

    # ---------- 交互 ----------

    def _on_metric_change(self, index):
        # 下拉变化可能来自维度或"最低命中数"，统一按当前维度刷新
        self.current_metric = self.metric_combo.itemData(self.metric_combo.currentIndex())
        if self.market_data:
            self._render_table()

    def _on_row_double_clicked(self, index):
        """双击某行：把该股加入盯盘（发信号给主窗口）。"""
        row = index.row()
        recs = getattr(self, "_current_rows", None)
        if not recs or not (0 <= row < len(recs)):
            return
        symbol = recs[row].get("symbol")
        if symbol:
            self.add_to_watchlist.emit(symbol)

    def _post_status(self, msg):
        QTimer.singleShot(0, lambda: self.status_label.setText(msg))
