#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main.py —— A股实时盯盘助手 入口脚本。

运行：
    python3 main.py

功能：
    - 自选股实时行情盯盘（每 5 秒自动刷新，可调）
    - 涨跌阈值报警、放量异动、技术指标（RSI）信号报警
    - K 线图 + 均线 + MACD 可视化
    - 技术指标面板（MA / MACD / RSI / KDJ / 量比）

依赖：仅 PyQt5（如未安装：pip3 install PyQt5）
数据源：腾讯股票行情接口（免费，无需 token）
"""

import os
import sys


def main():
    # 高 DPI 适配：必须在 QApplication 创建前设置，让高分屏(4K/Retina)字体自动放大。
    try:
        from PyQt5.QtCore import Qt
        Qt.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        Qt.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    except Exception:
        pass

    from PyQt5.QtWidgets import QApplication
    from ui_main import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName("A股实时盯盘助手")

    # 可选：通过环境变量 QT_SCALE_FACTOR 在启动时强制整体缩放（含字体）。
    # 例如 QT_SCALE_FACTOR=1.5 python3 main.py
    # 高分屏若自动缩放偏小，可设此变量放大整体界面。
    try:
        if os.environ.get("QT_SCALE_FACTOR"):
            app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
            app.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    except Exception:
        pass

    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
